const THREE = window.THREE;
window.addEventListener('error', function(ev) {
  const box = document.getElementById('startup-error') || document.createElement('div');
  box.id = 'startup-error';
  box.style.cssText = 'position:fixed;z-index:99999;left:8px;right:8px;top:8px;padding:12px;background:#300;color:#fff;font:14px Arial;border:1px solid #f66;border-radius:8px;white-space:pre-wrap';
  box.textContent = 'Erro ao iniciar o jogo: ' + (ev.message || 'falha de JavaScript') + '\\nRecarregue a página e confira se a internet está ativa.';
  document.body.appendChild(box);
});
'use strict';

/* =========================================================
   OPEN WORLD MASTER BUILD
   Unificado e otimizado para celulares modestos
   ========================================================= */

let scene,camera,renderer,directionalLight;
let player,vehicle;
let inVehicle=false;
let speed=0,steering=0,fuel=100,carDamage=0;
let carVelocity=new THREE.Vector3(),carBody=null,wheelMeshes=[];
let buildingColliders=[],cityLocations=[];
let asphaltTexture,sidewalkTexture,facadeTexture,facadeTextures=[],grassTexture,parkGrassTexture;
let activeFacadeIndex=0;
const CITY_LIMIT=785;
const CITY_EDGE=750;
let lastLocationUpdate=0,lastNearbyLocation=-1;
let cameraAngleY=0;
let money=0,playerHealth=100,ammoCount=50;
let gameTime=12,timeSpeed=.002;
let isGamePaused=false,gameStarted=false,gameOver=false;
let keys={forward:false,backward:false,left:false,right:false};
let pedestrians=[],npcVehicles=[],policeCars=[],bullets=[],smokeParticles=[];
let hiddenPackages=[],collectedPackagesCount=0;
let streetLights=[],neonSigns=[],ambientAircrafts=[],streetLampMaterial=null;
let ambientDustParticles=null,rainParticles=null,minimapCtx=null;
let currentMission=null,missionMarker=null,gpsTarget=null;
let wantedLevel=0,currentWeaponIndex=0,currentWeapon="Pistola 9mm",wantedSearchTimer=0;
let weaponAmmo=[50,120,90,30];
let isRaining=false,cameraMode=0;
let isRacing=false,raceTimer=0,currentCheckpoint=0;
let unlockedAchievements=[],storedGarageVehicles=[];
let audioCtx=null,engineOscillator=null,engineGain=null;
let radioPlaying=false,currentStation=0,radioInterval=null;
let lastFrame=performance.now(),lastHudUpdate=0,lastAIUpdate=0;
const clock=new THREE.Clock();

const weaponsList=[
 {name:"Pistola 9mm",damage:25,range:55,fireDelay:.25,projectiles:1,spread:.012,velocity:2.7,color:0xffdf55},
 {name:"Submetralhadora SMG",damage:12,range:42,fireDelay:.085,projectiles:1,spread:.055,velocity:2.5,color:0xffa83a},
 {name:"Fuzil de Assalto M4",damage:38,range:90,fireDelay:.15,projectiles:1,spread:.018,velocity:3.2,color:0xfff18a},
 {name:"Escopeta 12",damage:14,range:24,fireDelay:.58,projectiles:7,spread:.22,velocity:2.25,color:0xff7250}
];

const raceCheckpoints=[
 {x:50,z:50},{x:120,z:-80},{x:-60,z:-150},{x:-140,z:80}
];

function $(id){return document.getElementById(id)}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function playerPos(){return inVehicle&&vehicle?vehicle.position:player.position}
function updateNearbyLocation(){
 const pos=playerPos();let nearest=-1,best=105*105;
 for(let i=0;i<cityLocations.length;i++){const place=cityLocations[i],dx=pos.x-place.x,dz=pos.z-place.z,d=dx*dx+dz*dz;if(d<best){best=d;nearest=i}}
 if(nearest!==lastNearbyLocation){lastNearbyLocation=nearest;const label=$("location-name");if(label)label.innerText=nearest>=0?cityLocations[nearest].name:"Explorando Alta Vista"}
}
function loadTiledTexture(path,repeatX,repeatY){
 const texture=new THREE.TextureLoader().load(path);
 texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
 texture.repeat.set(repeatX,repeatY);
 texture.encoding=THREE.sRGBEncoding;
 return texture;
}

/* ---------- CORE ---------- */
function initEngine(){
 asphaltTexture=loadTiledTexture("img/asphalt-texture.png",60,5);
 sidewalkTexture=loadTiledTexture("img/sidewalk-texture.png",90,1.5);
 facadeTextures=[
  loadTiledTexture("img/facade-texture.png",2,3),
  loadTiledTexture("img/facade-brick.png",2,3),
  loadTiledTexture("img/facade-glass.png",2,3),
  loadTiledTexture("img/facade-stone.png",2,3),
  loadTiledTexture("img/facade-stucco.png",2,3)
 ];
 facadeTexture=facadeTextures[0];
 grassTexture=loadTiledTexture("img/park-grass-texture.png",100,100);
 parkGrassTexture=loadTiledTexture("img/park-grass-texture.png",6,6);
 scene=new THREE.Scene();
 scene.background=new THREE.Color(0x87ceeb);
 scene.fog=new THREE.FogExp2(0x8899aa,.0011);

 camera=new THREE.PerspectiveCamera(70,innerWidth/innerHeight,.1,1200);
 camera.position.set(0,4,8);

 renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:"high-performance"});
 renderer.setSize(innerWidth,innerHeight);
 renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.35));
 renderer.outputEncoding=THREE.sRGBEncoding;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;
 renderer.toneMappingExposure=1.05;
 document.body.appendChild(renderer.domElement);

 const ambient=new THREE.HemisphereLight(0xdcecff,0x66704d,.78);
 scene.add(ambient);

 directionalLight=new THREE.DirectionalLight(0xfff2dc,1.15);
 directionalLight.position.set(50,100,50);
 scene.add(directionalLight);

 const floor=new THREE.Mesh(
   new THREE.PlaneGeometry(1600,1600),
   new THREE.MeshStandardMaterial({color:0x9ca57d,map:grassTexture,roughness:1})
 );
 floor.rotation.x=-Math.PI/2;
 floor.receiveShadow=false;
 scene.add(floor);

 createRoads();
 createPlayer();
 createVehicle();
 createBuildings();
 addParkingLots();
 relocateSpawnPoints();
 createPedestrians(110);
}

function createRoads(){
 const roadMat=new THREE.MeshStandardMaterial({color:0x777777,map:asphaltTexture,roughness:1});
 const sidewalkMat=new THREE.MeshStandardMaterial({color:0xaaa69c,map:sidewalkTexture,roughness:.95});
 const curbMat=new THREE.MeshStandardMaterial({color:0xb9b6ad,roughness:.9});
 const paint=new THREE.MeshBasicMaterial({color:0xe8dfb5});
 const edge=new THREE.MeshBasicMaterial({color:0xd5d2c8});
 const dashHorizontal=[],dashVertical=[];
 const dummy=new THREE.Object3D();
 for(let street=-CITY_EDGE;street<=CITY_EDGE;street+=100){
  const roadX=new THREE.Mesh(new THREE.PlaneGeometry(CITY_EDGE*2,18),roadMat);
  roadX.rotation.x=-Math.PI/2;roadX.position.set(0,.025,street);scene.add(roadX);
  const roadZ=new THREE.Mesh(new THREE.PlaneGeometry(18,CITY_EDGE*2),roadMat);
  roadZ.rotation.x=-Math.PI/2;roadZ.position.set(street,.03,0);scene.add(roadZ);
  for(const side of [-1,1]){
   const walkX=new THREE.Mesh(new THREE.PlaneGeometry(CITY_EDGE*2,6),sidewalkMat);
   walkX.rotation.x=-Math.PI/2;walkX.position.set(0,.04,street+side*12.2);scene.add(walkX);
   const walkZ=new THREE.Mesh(new THREE.PlaneGeometry(6,CITY_EDGE*2),sidewalkMat);
   walkZ.rotation.x=-Math.PI/2;walkZ.position.set(street+side*12.2,.045,0);scene.add(walkZ);
   const curbX=new THREE.Mesh(new THREE.BoxGeometry(CITY_EDGE*2,.22,.3),curbMat);
   curbX.position.set(0,.14,street+side*9.15);scene.add(curbX);
   const curbZ=new THREE.Mesh(new THREE.BoxGeometry(.3,.22,CITY_EDGE*2),curbMat);
   curbZ.position.set(street+side*9.15,.14,0);scene.add(curbZ);
   const edgeX=new THREE.Mesh(new THREE.BoxGeometry(CITY_EDGE*2,.035,.12),edge);
   edgeX.position.set(0,.052,street+side*8.2);scene.add(edgeX);
   const edgeZ=new THREE.Mesh(new THREE.BoxGeometry(.12,.035,CITY_EDGE*2),edge);
   edgeZ.position.set(street+side*8.2,.057,0);scene.add(edgeZ);
  }
  for(let along=-CITY_EDGE;along<=CITY_EDGE;along+=10){
   if(Math.min(Math.abs(along%100),100-Math.abs(along%100))<13)continue;
   dashHorizontal.push([along,street]);
   dashVertical.push([street,along]);
  }
 }
 const horizontal=new THREE.InstancedMesh(new THREE.BoxGeometry(4,.04,.18),paint,dashHorizontal.length);
 dashHorizontal.forEach(([x,z],i)=>{dummy.position.set(x,.055,z);dummy.rotation.set(0,0,0);dummy.updateMatrix();horizontal.setMatrixAt(i,dummy.matrix)});
 scene.add(horizontal);
 const vertical=new THREE.InstancedMesh(new THREE.BoxGeometry(.18,.04,4),paint,dashVertical.length);
 dashVertical.forEach(([x,z],i)=>{dummy.position.set(x,.06,z);dummy.rotation.set(0,0,0);dummy.updateMatrix();vertical.setMatrixAt(i,dummy.matrix)});
 scene.add(vertical);
}

function createCharacterGroup(colors={shirt:0x1475df,pants:0x26354a,skin:0xe3ad82}){
 const root=new THREE.Group();
 const shirt=new THREE.MeshStandardMaterial({color:colors.shirt,roughness:.62});
 const pants=new THREE.MeshStandardMaterial({color:colors.pants,roughness:.78});
 const skin=new THREE.MeshStandardMaterial({color:colors.skin,roughness:.72});
 const shoe=new THREE.MeshStandardMaterial({color:0x202126,roughness:.8});
 const torso=new THREE.Mesh(new THREE.BoxGeometry(.62,.78,.34),shirt);torso.position.y=1.22;root.add(torso);
 const hips=new THREE.Mesh(new THREE.BoxGeometry(.48,.24,.3),pants);hips.position.y=.72;root.add(hips);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.22,12,10),skin);head.position.y=1.83;root.add(head);
 const hair=new THREE.Mesh(new THREE.SphereGeometry(.225,12,8,0,Math.PI*2,0,Math.PI*.58),new THREE.MeshStandardMaterial({color:0x30251f,roughness:.95}));hair.position.y=1.89;root.add(hair);
 const arms=[],legs=[];
 for(const side of [-1,1]){
  const arm=new THREE.Group();arm.position.set(side*.39,1.48,0);root.add(arm);
  const upper=new THREE.Mesh(new THREE.CylinderGeometry(.105,.13,.43,8),shirt);upper.position.y=-.22;arm.add(upper);
  const fore=new THREE.Mesh(new THREE.CylinderGeometry(.075,.09,.36,8),skin);fore.position.set(0,-.58,-.015);arm.add(fore);arms.push(arm);
  const leg=new THREE.Group();leg.position.set(side*.16,.68,0);root.add(leg);
  const thigh=new THREE.Mesh(new THREE.CylinderGeometry(.12,.14,.4,8),pants);thigh.position.y=-.2;leg.add(thigh);
  const shin=new THREE.Mesh(new THREE.CylinderGeometry(.075,.1,.34,8),pants);shin.position.y=-.55;leg.add(shin);
  const foot=new THREE.Mesh(new THREE.BoxGeometry(.17,.11,.28),shoe);foot.position.set(0,-.72,-.06);leg.add(foot);legs.push(leg);
 }
 root.userData={arms,legs,walkPhase:Math.random()*6,character:true};
 return root;
}
function createPlayer(){
 player=createCharacterGroup({shirt:0x087be8,pants:0x26354a,skin:0xe3ad82});
 player.position.set(0,0,8);scene.add(player);
}
function animateCharacter(character,dt,moving=true){
 if(!character||!character.userData.character)return;
 const ud=character.userData;ud.walkPhase=(ud.walkPhase||0)+dt*(moving?10:2);
 const swing=moving?Math.sin(ud.walkPhase)*.58:0;
 ud.legs.forEach((limb,i)=>{limb.rotation.x=(i===0?1:-1)*swing});
 ud.arms.forEach((limb,i)=>{limb.rotation.x=(i===0?-1:1)*swing*.8});
}

function createVehicle(){
 vehicle=new THREE.Group();
 const paint=new THREE.MeshStandardMaterial({color:0xd52657,roughness:.16,metalness:.72});
 const glass=new THREE.MeshStandardMaterial({color:0x172b3a,roughness:.18,metalness:.25});
 const rubber=new THREE.MeshStandardMaterial({color:0x17191c,roughness:.92});
 carBody=new THREE.Group();vehicle.add(carBody);
 const lower=new THREE.Mesh(new THREE.BoxGeometry(2,.58,4.15),paint);
 lower.position.y=.67;carBody.add(lower);
 const hood=new THREE.Mesh(new THREE.BoxGeometry(1.82,.22,1.32),paint);
 hood.position.set(0,1.03,-1.18);carBody.add(hood);
 const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.52,.72,1.95),glass);
 cabin.position.set(0,1.25,.08);carBody.add(cabin);
 const roof=new THREE.Mesh(new THREE.BoxGeometry(1.42,.12,1.58),paint);
 roof.position.set(0,1.64,.13);carBody.add(roof);
 const bumperMat=new THREE.MeshStandardMaterial({color:0x282b30,metalness:.55,roughness:.4});
 for(const z of [-2.12,2.12]){
  const bumper=new THREE.Mesh(new THREE.BoxGeometry(1.9,.18,.16),bumperMat);
  bumper.position.set(0,.46,z);carBody.add(bumper);
 }
 const headlightMat=new THREE.MeshStandardMaterial({color:0xfff1cb,emissive:0xffd27a,emissiveIntensity:.8});
 const tailMat=new THREE.MeshStandardMaterial({color:0xc21c2c,emissive:0x66000a,emissiveIntensity:.45});
 for(const x of [-.68,.68]){
  const headlight=new THREE.Mesh(new THREE.BoxGeometry(.38,.2,.08),headlightMat);
  headlight.position.set(x,.78,-2.1);carBody.add(headlight);
  const tail=new THREE.Mesh(new THREE.BoxGeometry(.38,.2,.08),tailMat);
  tail.position.set(x,.78,2.1);carBody.add(tail);
 }
 const wheelGeo=new THREE.CylinderGeometry(.39,.39,.28,12);
 for(const x of [-.98,.98])for(const z of [-1.34,1.34]){
  const wheel=new THREE.Mesh(wheelGeo,rubber);wheel.rotation.z=Math.PI/2;
  wheel.position.set(x,.4,z);vehicle.add(wheel);wheelMeshes.push(wheel);
 }
 vehicle.position.set(2.5,0,4);
 scene.add(vehicle);
}

function addCityBuilding(x,z,width,depth,height,tint){
 const variation=Math.abs(Math.round(x*11+z*7))%9;
 width*=.93+(variation%5)*.025;depth*=.92+((variation*3)%5)*.025;height*=.86+((variation*5)%7)*.035;
 const geometry=new THREE.BoxGeometry(width,height,depth);
 const facadeColor=new THREE.Color(tint).offsetHSL(0,(variation-4)*.012,(variation-4)*.018);
 const material=new THREE.MeshStandardMaterial({color:facadeColor,map:facadeTextures[activeFacadeIndex]||facadeTexture,roughness:.88,metalness:activeFacadeIndex===2 ? .24 : .04});
 const building=new THREE.Mesh(geometry,material);
 building.position.set(x,height/2,z);scene.add(building);
 const roof=new THREE.Mesh(new THREE.BoxGeometry(width+.6,.4,depth+.6),new THREE.MeshStandardMaterial({color:0x625f5a,roughness:.9}));
 roof.position.set(x,height+.2,z);scene.add(roof);
 buildingColliders.push({x,z,halfX:width/2,halfZ:depth/2});
 return building;
}
function addLocationSign(location){
 const canvas=document.createElement("canvas");canvas.width=256;canvas.height=64;
 const ctx=canvas.getContext("2d");
 ctx.fillStyle="#12333a";ctx.fillRect(0,0,256,64);
 ctx.fillStyle="#24c3b4";ctx.fillRect(0,0,7,64);
 ctx.fillStyle="#f7f1da";ctx.textAlign="center";ctx.textBaseline="middle";
 ctx.font="bold 16px Arial";ctx.fillText(location.title,136,21,236);
 ctx.font="bold 12px Arial";ctx.fillStyle="#7ce0d0";ctx.fillText(location.district,136,46,230);
 const texture=new THREE.CanvasTexture(canvas);texture.encoding=THREE.sRGBEncoding;
 const board=new THREE.Mesh(new THREE.BoxGeometry(19,3.8,.45),new THREE.MeshStandardMaterial({color:0x18232a,roughness:.6}));
 board.position.set(location.x,5.2,location.z+(location.z>0?-28:28));
 const face=new THREE.Mesh(new THREE.PlaneGeometry(18.4,3.25),new THREE.MeshBasicMaterial({map:texture,side:THREE.DoubleSide}));
 face.position.set(board.position.x,board.position.y,board.position.z+(location.z>0?-.24:.24));
 if(location.z>0)face.rotation.y=Math.PI;
 scene.add(board,face);
}
function addVenueDetails(location){
 const {x,z,type}=location;
 const concrete=new THREE.MeshStandardMaterial({color:0xaaa79e,map:sidewalkTexture,roughness:.92});
 if(type===0){
  const lawn=new THREE.Mesh(new THREE.PlaneGeometry(68,68),new THREE.MeshStandardMaterial({color:0xaab98b,map:parkGrassTexture,roughness:1}));
  lawn.rotation.x=-Math.PI/2;lawn.position.set(x,.012,z);scene.add(lawn);
  const pathA=new THREE.Mesh(new THREE.PlaneGeometry(4,64),concrete);pathA.rotation.x=-Math.PI/2;pathA.position.set(x,.025,z);scene.add(pathA);
  const pathB=new THREE.Mesh(new THREE.PlaneGeometry(64,4),concrete);pathB.rotation.x=-Math.PI/2;pathB.position.set(x,.03,z);scene.add(pathB);
  addCityBuilding(x,z,14,12,6,0xd9d1b5);
 }else if(type===1){
  addCityBuilding(x,z,42,31,14,0xf0d9b6);
  for(const side of [-1,1]){const stall=new THREE.Mesh(new THREE.BoxGeometry(9,4,8),new THREE.MeshStandardMaterial({color:side<0?0xc86743:0x398d80,roughness:.8}));stall.position.set(x+side*25,2,z+17);scene.add(stall)}
 }else if(type===2){
  addCityBuilding(x-7,z,34,30,30,0xe6e8e4);addCityBuilding(x+22,z+9,17,18,17,0xf1f0e9);
  const crossMat=new THREE.MeshStandardMaterial({color:0xd64b46,emissive:0x43100c});
  const crossA=new THREE.Mesh(new THREE.BoxGeometry(5,.7,1),crossMat);crossA.position.set(x,25,z-15);scene.add(crossA);
  const crossB=new THREE.Mesh(new THREE.BoxGeometry(1,.7,5),crossMat);crossB.position.set(x,25,z-15);scene.add(crossB);
 }else if(type===3){
  addCityBuilding(x,z,48,24,12,0xc9d0ce);
  const canopy=new THREE.Mesh(new THREE.BoxGeometry(52,.65,7),new THREE.MeshStandardMaterial({color:0x357f89,metalness:.25,roughness:.5}));canopy.position.set(x,8,z+20);scene.add(canopy);
  for(let t=-1;t<=1;t++){const rail=new THREE.Mesh(new THREE.BoxGeometry(54,.12,.12),new THREE.MeshStandardMaterial({color:0x555b5e,metalness:.7}));rail.position.set(x,.22,z+t*2);scene.add(rail)}
 }else if(type===4){
  addCityBuilding(x,z,34,30,18,0xdccfae);
  const columnGeo=new THREE.CylinderGeometry(.65,.8,6,8),columnMat=new THREE.MeshStandardMaterial({color:0xeee4cf,roughness:.75});
  for(let c=-2;c<=2;c++){const column=new THREE.Mesh(columnGeo,columnMat);column.position.set(x+c*5,3,z-16);scene.add(column)}
 }else if(type===5){
  const arena=new THREE.Mesh(new THREE.CylinderGeometry(25,27,15,16),new THREE.MeshStandardMaterial({color:0x899599,map:facadeTextures[activeFacadeIndex]||facadeTexture,roughness:.8}));arena.position.set(x,7.5,z);scene.add(arena);
  const roof=new THREE.Mesh(new THREE.TorusGeometry(24,.8,8,24),new THREE.MeshStandardMaterial({color:0x3b5961,metalness:.3,roughness:.6}));roof.rotation.x=Math.PI/2;roof.position.set(x,15,z);scene.add(roof);
  buildingColliders.push({x,z,halfX:26,halfZ:26});
 }else if(type===6){
  addCityBuilding(x,z,38,29,20,0xe0d8c9);
  const columnGeo=new THREE.CylinderGeometry(.42,.55,8,8),columnMat=new THREE.MeshStandardMaterial({color:0xeee5d8,roughness:.7});
  for(let c=-2;c<=2;c++){const column=new THREE.Mesh(columnGeo,columnMat);column.position.set(x+c*5,4,z-15);scene.add(column)}
 }else if(type===7){
  addCityBuilding(x-11,z,25,35,17,0xd4dcd9);addCityBuilding(x+13,z,25,35,14,0xe4d5bd);
  const atrium=new THREE.Mesh(new THREE.BoxGeometry(13,11,18),new THREE.MeshStandardMaterial({color:0x4794a0,metalness:.2,roughness:.3}));atrium.position.set(x,5.5,z-4);scene.add(atrium);
 }else if(type===8){
  const plaza=new THREE.Mesh(new THREE.PlaneGeometry(64,64),concrete);plaza.rotation.x=-Math.PI/2;plaza.position.set(x,.015,z);scene.add(plaza);
  const pool=new THREE.Mesh(new THREE.CylinderGeometry(6,6,.45,16),new THREE.MeshStandardMaterial({color:0x45a9b5,metalness:.4,roughness:.2,transparent:true,opacity:.86}));pool.position.set(x,.25,z);scene.add(pool);
  const rim=new THREE.Mesh(new THREE.TorusGeometry(6,.45,8,20),new THREE.MeshStandardMaterial({color:0xd6d0bd,roughness:.72}));rim.rotation.x=Math.PI/2;rim.position.set(x,.5,z);scene.add(rim);
 }else if(type===9){
  addCityBuilding(x-14,z,22,25,14,0xe2ddc9);addCityBuilding(x+13,z-7,24,23,21,0xd3d9d4);
  const hall=new THREE.Mesh(new THREE.BoxGeometry(14,7,12),new THREE.MeshStandardMaterial({color:0x417d86,metalness:.2,roughness:.4}));hall.position.set(x,3.5,z+17);scene.add(hall);
 }else if(type===10){
  addCityBuilding(x,z,46,29,15,0xe2d7c7);
  const doorMat=new THREE.MeshStandardMaterial({color:0x28343b,roughness:.45});
  for(let bay=-1;bay<=1;bay++){const door=new THREE.Mesh(new THREE.BoxGeometry(8,5,.28),doorMat);door.position.set(x+bay*13,2.5,z-14.8);scene.add(door)}
  const tower=new THREE.Mesh(new THREE.BoxGeometry(9,24,9),new THREE.MeshStandardMaterial({color:0xc55d45,map:facadeTextures[activeFacadeIndex]||facadeTexture,roughness:.8}));tower.position.set(x-25,12,z+17);scene.add(tower);
 }else if(type===11){
  addCityBuilding(x,z-18,32,16,10,0xe0eee3);
  const glassHouse=new THREE.Mesh(new THREE.BoxGeometry(35,10,19),new THREE.MeshStandardMaterial({color:0x72a99b,transparent:true,opacity:.48,metalness:.15,roughness:.2}));glassHouse.position.set(x,5,z+13);scene.add(glassHouse);
  const roof=new THREE.Mesh(new THREE.ConeGeometry(24,13,8),new THREE.MeshStandardMaterial({color:0x659366,roughness:.8}));roof.position.set(x,6.5,z-14);scene.add(roof);
 }else if(type===12){
  addCityBuilding(x-13,z-13,28,24,17,0xc3d0d2);
  const pad=new THREE.Mesh(new THREE.CylinderGeometry(17,17,.45,20),new THREE.MeshStandardMaterial({color:0x525d60,roughness:.86}));pad.position.set(x+17,.24,z+15);scene.add(pad);
  const hMat=new THREE.MeshBasicMaterial({color:0xffdf5c});
  const h1=new THREE.Mesh(new THREE.BoxGeometry(2,.05,12),hMat);h1.position.set(x+17,.5,z+15);scene.add(h1);
  const h2=new THREE.Mesh(new THREE.BoxGeometry(10,.05,2),hMat);h2.position.set(x+17,.5,z+15);scene.add(h2);
 }else if(type===13){
  addCityBuilding(x-9,z,34,29,18,0xd7e2df);
  const tank=new THREE.Mesh(new THREE.CylinderGeometry(9,9,12,20),new THREE.MeshStandardMaterial({color:0x38a9c5,transparent:true,opacity:.72,metalness:.22,roughness:.18}));tank.position.set(x+17,6,z+8);scene.add(tank);
  for(let b=0;b<6;b++){const bubble=new THREE.Mesh(new THREE.SphereGeometry(.55+(b%2)*.3,7,6),new THREE.MeshBasicMaterial({color:0xb6f4f1,transparent:true,opacity:.75}));bubble.position.set(x+12+(b%3)*4,2+(b%4)*2,z+8);scene.add(bubble)}
 }else{
  addCityBuilding(x,z,42,29,19,0x943f43);
  const marquee=new THREE.Mesh(new THREE.BoxGeometry(22,3,.8),new THREE.MeshStandardMaterial({color:0xf1cf86,emissive:0x523410,roughness:.5}));marquee.position.set(x,10,z-15);scene.add(marquee);
  const awning=new THREE.Mesh(new THREE.BoxGeometry(32,.55,6),new THREE.MeshStandardMaterial({color:0xb55245,roughness:.7}));awning.position.set(x,6,z-20);scene.add(awning);
 }
}
function createBuildings(){
 const venueNames=["Parque das Palmeiras","Mercado Municipal","Hospital São Miguel","Estação das Artes","Biblioteca Central","Arena Horizonte","Museu da Cidade","Galeria Alameda","Praça das Fontes","Campus Universitário","Quartel dos Bombeiros","Jardim Botânico","Heliporto Metropolitano","Aquário Atlântico","Teatro Municipal"];
 const districts=["do Centro","das Acácias","de Santa Marina","da Aurora","do Porto","das Flores","do Vale Verde","da Esperança","do Lago Norte","da Serra Azul","do Mirante","da Estação","das Colinas","do Horizonte","da Enseada"];
 for(let row=0;row<15;row++)for(let col=0;col<15;col++){
  const x=-700+col*100,z=-700+row*100,type=(col*7+row*11)%15;
  const location={x,z,type,title:venueNames[type],district:districts[row],name:venueNames[type]+" "+districts[row],skin:(row*7+col*11)%facadeTextures.length};
  cityLocations.push(location);
  activeFacadeIndex=location.skin;
  addVenueDetails(location);
  addLocationSign(location);
 }
}

function addParkingLots(){
 const lineMat=new THREE.MeshBasicMaterial({color:0xf1e6ad});
 const kinds=['bmw','mercedes','uno'];
 for(let street=-600;street<=600;street+=200){
  for(let along=-600;along<=600;along+=200){
   const x=street+19,z=along+27;
   if(!isClearParkingArea(x,z))continue;
   for(let slot=0;slot<3;slot++){
    const zz=z+slot*5.4;
    for(const side of [-1,1]){
     const mark=new THREE.Mesh(new THREE.BoxGeometry(.07,.025,4.5),lineMat);mark.position.set(x+side*1.25,.06,zz);scene.add(mark);
    }
    if(Math.random()<.52){
     const kind=kinds[Math.floor(Math.random()*kinds.length)];
     const car=createDetailedParkedCar(kind);
     car.scale.setScalar(.88);
     car.position.set(x,0,zz);car.rotation.y=Math.PI;scene.add(car);
    }
   }
  }
 }
}
function isClearParkingArea(x,z){
 return buildingColliders.every(b=>!(Math.abs(x-b.x)<b.halfX+4 && Math.abs(z-b.z)<b.halfZ+8));
}

// Vagas especiais com três carros reconhecíveis. O BMW usa um modelo GLB real;
// Mercedes e Uno usam malhas locais detalhadas para funcionar mesmo offline.
function createDetailedParkedCar(kind){
 const g=new THREE.Group();
 const cfg=kind==='mercedes'
  ? {w:1.9,l:4.1,h:.72,color:0x20252c,roof:.10,cabin:1.82}
  : kind==='bmw'
  ? {w:1.88,l:4.05,h:.70,color:0x2479b8,roof:.10,cabin:1.78}
  : {w:1.66,l:3.45,h:.68,color:0x176b42,roof:.16,cabin:1.48};
 const paint=new THREE.MeshStandardMaterial({color:cfg.color,roughness:.32,metalness:.48});
 const glass=new THREE.MeshStandardMaterial({color:0x182a35,roughness:.22,metalness:.18});
 const black=new THREE.MeshStandardMaterial({color:0x141619,roughness:.82});
 const chrome=new THREE.MeshStandardMaterial({color:0xc4cbd0,metalness:.75,roughness:.3});
 const lamp=new THREE.MeshStandardMaterial({color:0xfff1c4,emissive:0x504322,roughness:.35});
 const tail=new THREE.MeshStandardMaterial({color:0xc91f2c,emissive:0x330609,roughness:.35});
 const body=new THREE.Mesh(new THREE.BoxGeometry(cfg.w,cfg.h,cfg.l),paint);body.position.y=.62;g.add(body);
 const hood=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.94,.15,cfg.l*.29),paint);hood.position.set(0,.94,-cfg.l*.32);g.add(hood);
 const cabin=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.78,kind==='uno'?.60:.53,cfg.cabin),glass);cabin.position.set(0,1.14,kind==='uno'?.10:.05);g.add(cabin);
 const roof=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.72,.10,cfg.cabin*.7),paint);roof.position.set(0,1.47,kind==='uno'?.12:.04);g.add(roof);
 const grille=new THREE.Mesh(new THREE.BoxGeometry(kind==='uno'?.58:.72,.17,.05),kind==='uno'?black:chrome);grille.position.set(0,.78,-cfg.l/2-.025);g.add(grille);
 if(kind==='mercedes'){
  const star=new THREE.Mesh(new THREE.CylinderGeometry(.095,.095,.025,8),chrome);star.rotation.x=Math.PI/2;star.position.set(0,.82,-cfg.l/2-.055);g.add(star);
 }else{
  const badge=new THREE.Mesh(new THREE.BoxGeometry(.20,.07,.035),chrome);badge.position.set(0,.83,-cfg.l/2-.05);g.add(badge);
 }
 for(const x of [-cfg.w*.34,cfg.w*.34]){
  const head=new THREE.Mesh(new THREE.BoxGeometry(.25,.13,.055),lamp);head.position.set(x,.82,-cfg.l/2-.03);g.add(head);
  const rear=new THREE.Mesh(new THREE.BoxGeometry(.20,.14,.055),tail);rear.position.set(x,.79,cfg.l/2+.025);g.add(rear);
 }
 const wheelGeo=new THREE.CylinderGeometry(kind==='uno'?.26:.30,kind==='uno'?.26:.30,.18,8);
 const rimGeo=new THREE.CylinderGeometry(.14,.14,.19,8);
 for(const x of [-cfg.w*.49,cfg.w*.49])for(const z of [-cfg.l*.31,cfg.l*.31]){
  const wheel=new THREE.Mesh(wheelGeo,black);wheel.rotation.z=Math.PI/2;wheel.position.set(x,.36,z);g.add(wheel);
  const rim=new THREE.Mesh(rimGeo,chrome);rim.rotation.z=Math.PI/2;rim.position.set(x*1.015,.36,z);g.add(rim);
 }
 g.userData.brandCar=kind;return g;
}
function addBrandCarsToParking(){ /* Todos os carros estacionados já usam BMW, Mercedes ou Uno. */ }

// Spawn seguro: evita iniciar dentro das caixas de colisão dos prédios.
function isClearSpawn(x,z,radius){
 for(const b of buildingColliders){
  if(Math.abs(x-b.x)<b.halfX+radius && Math.abs(z-b.z)<b.halfZ+radius) return false;
 }
 return true;
}
function findClearSpawn(radius,avoidPosition=null){
 for(let ring=0;ring<=60;ring++){
  const d=ring*12.5;
  const candidates=ring===0?[[12.5,25]]:[[d,25],[-d,25],[25,d],[25,-d],[d,-25],[-d,-25],[-25,d],[-25,-d],[d,d],[-d,d],[d,-d],[-d,-d]];
  for(const [x,z] of candidates){
   if(Math.abs(x)<CITY_LIMIT-10 && Math.abs(z)<CITY_LIMIT-10 && isClearSpawn(x,z,radius) && (!avoidPosition || Math.hypot(x-avoidPosition.x,z-avoidPosition.z)>8)) return new THREE.Vector3(x,0,z);
  }
 }
 return new THREE.Vector3(50,0,50);
}
function relocateSpawnPoints(){
 if(player) player.position.copy(findClearSpawn(.8));
 if(vehicle){vehicle.position.copy(findClearSpawn(2.8,player?player.position:null));vehicle.rotation.set(0,0,0);carVelocity.set(0,0,0);}
}

function createPedestrians(n){
 const mat=new THREE.MeshStandardMaterial({color:0xffaa66});
 for(let i=0;i<n;i++){
  const p=new THREE.Group();
  const m=new THREE.Mesh(new THREE.CylinderGeometry(.3,.3,1.4,6),mat);
  m.position.y=.8;p.add(m);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.28,6,5),mat); head.position.y=1.65; p.add(head);
  const street=(Math.floor(Math.random()*16)-7.5)*100,along=(Math.random()-.5)*1460,side=Math.random()<.5?-1:1;
  if(Math.random()<.5)p.position.set(street+side*12.5,0,along);else p.position.set(along,0,street+side*12.5);
  p.userData={isRagdoll:false,patrolAngle:Math.random()*Math.PI*2};
  scene.add(p);pedestrians.push(p);
 }
}

/* ---------- CONTROLS ---------- */
function setupCameraDrag(){
 let dragging=false,lastX=0,lastY=0;
 const canvas=renderer.domElement;
 canvas.style.touchAction='none';
 canvas.addEventListener('pointerdown',e=>{
  if(e.target!==canvas)return;
  dragging=true;lastX=e.clientX;lastY=e.clientY;
  if(canvas.setPointerCapture) canvas.setPointerCapture(e.pointerId);
 });
 canvas.addEventListener('pointermove',e=>{
  if(!dragging)return;
  const dx=e.clientX-lastX;
  lastX=e.clientX;lastY=e.clientY;
  cameraAngleY-=dx*.008;
 });
 const stop=()=>{dragging=false};
 canvas.addEventListener('pointerup',stop);canvas.addEventListener('pointercancel',stop);
}

function setupControls(){
 const key=(e,v)=>{
  if(e.target&&["INPUT","TEXTAREA"].includes(e.target.tagName))return;
  const k=e.key.toLowerCase();
  if(k==="w"||k==="arrowup")keys.forward=v;
  if(k==="s"||k==="arrowdown")keys.backward=v;
  if(k==="a"||k==="arrowleft")keys.left=v;
  if(k==="d"||k==="arrowright")keys.right=v;
  if(k==="e"&&v)toggleVehicle();
  if(k==="c"&&v)toggleCameraMode();
  if((k==="p"||k==="escape")&&v)togglePauseGame();
  if((k==="q"||k==="tab")&&v){e.preventDefault();cycleWeaponArsenal()}
  if(k===" "&&v)shootWeapon();
 };
 addEventListener("keydown",e=>key(e,true));
 addEventListener("keyup",e=>key(e,false));


 $("btn-enter").onclick=toggleVehicle;
 $("btn-shoot").onclick=shootWeapon;
 $("btn-camera").onclick=toggleCameraMode;
 $("btn-music").onclick=toggleBackgroundMusic;
 $("btn-pause").onclick=togglePauseGame;
 setupJoystick();
}

function bindHold(id,getter,setter){
 const el=$(id);
 const on=e=>{e.preventDefault();setter(true)};
 const off=e=>{e.preventDefault();setter(false)};
 ["pointerdown"].forEach(x=>el.addEventListener(x,on));
 ["pointerup","pointercancel","pointerleave"].forEach(x=>el.addEventListener(x,off));
}

function setupJoystick(){
 const base=$("joystick"),stick=$("stick");
 let active=false;
 const move=e=>{
  if(!active)return;
  const r=base.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
  let dx=e.clientX-cx,dy=e.clientY-cy;
  const max=42,len=Math.hypot(dx,dy)||1;
  if(len>max){dx=dx/len*max;dy=dy/len*max}
  stick.style.transform=`translate(${dx}px,${dy}px)`;
  keys.left=dx<-10;keys.right=dx>10;keys.forward=dy<-10;keys.backward=dy>10;
 };
 base.addEventListener("pointerdown",e=>{active=true;base.setPointerCapture(e.pointerId);move(e)});
 base.addEventListener("pointermove",move);
 const release=()=>{active=false;stick.style.transform="";keys.left=keys.right=keys.forward=keys.backward=false};
 base.addEventListener("pointerup",release);base.addEventListener("pointercancel",release);base.addEventListener("lostpointercapture",release);
}

function toggleVehicle(){
 if(!vehicle)return;
 if(!inVehicle){
  if(player.position.distanceTo(vehicle.position)<5){
   inVehicle=true;player.visible=false;startEngineSound();
  }
 }else{
  inVehicle=false;player.visible=true;
  player.position.copy(vehicle.position).add(new THREE.Vector3(2,0,0));
  stopEngineSound();
 }
}

/* ---------- PLAYER / VEHICLE ---------- */
function updateGame(dt){
 if(inVehicle) updateVehicle(dt);
 else updatePlayer(dt);
}

function updatePlayer(dt){
 const move=.085*dt*60;
 const dir=new THREE.Vector3();
 if(keys.forward)dir.z-=1;
 if(keys.backward)dir.z+=1;
 if(keys.left)dir.x-=1;
 if(keys.right)dir.x+=1;
 if(dir.lengthSq()){
  dir.normalize();player.position.addScaledVector(dir,move);
  player.rotation.y=Math.atan2(dir.x,dir.z);
  animateCharacter(player,dt,true);
 }else animateCharacter(player,dt,false);
 player.position.x=clamp(player.position.x,-CITY_LIMIT,CITY_LIMIT);player.position.z=clamp(player.position.z,-CITY_LIMIT,CITY_LIMIT);
 const cameraOffset=new THREE.Vector3(0,4,7).applyAxisAngle(new THREE.Vector3(0,1,0),cameraAngleY);
 camera.position.lerp(player.position.clone().add(cameraOffset),.12);
 camera.lookAt(player.position.clone().add(new THREE.Vector3(0,1,0)));
}

function updateVehicle(dt){
 const throttle=keys.forward?1:keys.backward?-1:0;
 const maxSpeed=carDamage>=100?0:22;
 const steerInput=(keys.left?1:0)-(keys.right?1:0);
 steering+=(steerInput-steering)*Math.min(1,dt*5.5);
 const turnGrip=clamp(Math.abs(speed)/3.5,0,1.25);
 vehicle.rotation.y+=steering*turnGrip*1.35*Math.sign(speed||0)*dt;
 const forward=new THREE.Vector3(0,0,-1).applyQuaternion(vehicle.quaternion);
 const right=new THREE.Vector3(1,0,0).applyQuaternion(vehicle.quaternion);
 const forwardSpeed=carVelocity.dot(forward);
 let driveForce=0;
 if(throttle>0&&fuel>0)driveForce=forwardSpeed<0?19:10.5;
 else if(throttle<0)driveForce=forwardSpeed>0?-19:(fuel>0?-7:0);
 carVelocity.addScaledVector(forward,driveForce*dt);
 carVelocity.multiplyScalar(Math.exp(-(throttle===0?.42:.16)*dt));
 const longitudinal=clamp(carVelocity.dot(forward),-8,maxSpeed);
 const lateral=carVelocity.dot(right)*Math.exp(-3.4*dt);
 carVelocity.copy(forward.multiplyScalar(longitudinal).add(right.multiplyScalar(lateral)));
 speed=longitudinal;
 const previous=vehicle.position.clone();
 vehicle.position.addScaledVector(carVelocity,dt);
 let collided=false;
 for(const obstacle of buildingColliders){
  const dx=Math.abs(vehicle.position.x-obstacle.x),dz=Math.abs(vehicle.position.z-obstacle.z);
  if(dx<obstacle.halfX+1.25&&dz<obstacle.halfZ+2){
   vehicle.position.copy(previous);carVelocity.multiplyScalar(-.22);speed=carVelocity.dot(forward);
   carDamage=clamp(carDamage+Math.max(4,Math.abs(longitudinal)*.7),0,100);collided=true;break;
  }
 }
 if(collided)playSoundEffect("crash");
 if(vehicle.position.x<-CITY_LIMIT||vehicle.position.x>CITY_LIMIT){vehicle.position.x=clamp(vehicle.position.x,-CITY_LIMIT,CITY_LIMIT);carVelocity.x*=-.25}
 if(vehicle.position.z<-CITY_LIMIT||vehicle.position.z>CITY_LIMIT){vehicle.position.z=clamp(vehicle.position.z,-CITY_LIMIT,CITY_LIMIT);carVelocity.z*=-.25}
 fuel=Math.max(0,fuel-Math.abs(speed)*dt*.018);
 const wheelSpin=speed*dt/.39;
 for(const wheel of wheelMeshes)wheel.rotation.x+=wheelSpin;
 if(carBody)carBody.rotation.z=clamp(-steering*speed*.003,-.08,.08);
 updateVehicleCamera(dt);
 if(Math.abs(speed)>6&&carDamage>40&&Math.random()<dt*.8)createSmokeParticle(vehicle.position);
 updateEngineSound(speed/22);
}

/* ---------- TRAFFIC ---------- */
function createTrafficSystem(){
 const kinds=['bmw','mercedes','uno'];
 for(let i=0;i<42;i++){
  const car=createDetailedParkedCar(kinds[i%kinds.length]);
  car.scale.setScalar(kinds[i%kinds.length]==='uno'?.92:1.0);
  const axis=Math.random()<.5?'x':'z',street=(Math.floor(Math.random()*16)-7.5)*100;
  const direction=Math.random()<.5?1:-1,lane=(Math.random()<.5?-1:1)*4;
  if(axis==='x'){car.position.set((Math.random()-.5)*1460,0,street+lane);car.rotation.y=direction>0?-Math.PI/2:Math.PI/2}
  else{car.position.set(street+lane,0,(Math.random()-.5)*1460);car.rotation.y=direction>0?Math.PI:0}
  car.userData={speed:.28+Math.random()*.18,direction,axis,hitCooldown:0,type:i%3};
  scene.add(car);npcVehicles.push(car);
 }
}
function updateTraffic(dt){
 for(const npc of npcVehicles){
  const d=npc.userData.speed*npc.userData.direction*dt*60;
  if(npc.userData.axis==="x")npc.position.x+=d;else npc.position.z+=d;
  const p=npc.userData.axis==="x"?npc.position.x:npc.position.z;
  if(Math.abs(p)>CITY_LIMIT){npc.userData.direction*=-1;npc.rotation.y+=Math.PI;}
  if(npc.userData.hitCooldown>0)npc.userData.hitCooldown-=dt;
  if(inVehicle&&vehicle.position.distanceTo(npc.position)<3&&Math.abs(speed)>3&&npc.userData.hitCooldown<=0){
   carDamage=clamp(carDamage+clamp(Math.abs(speed)*1.1,8,30),0,100);
   carVelocity.multiplyScalar(-.28);speed*= -.28;npc.userData.hitCooldown=.75;addWanted(1);playSoundEffect("crash");
  }
 }
}

/* ---------- WEAPONS ---------- */
function setupWeaponSystem(){}
let shootCooldown=0;
function setupWeaponArsenalSystem(){updateWeaponHud()}
function updateWeaponHud(){
 const w=weaponsList[currentWeaponIndex];currentWeapon=w.name;ammoCount=weaponAmmo[currentWeaponIndex];
 if($("weapon-name"))$("weapon-name").innerText=w.name;
 if($("ammo-count"))$("ammo-count").innerText=ammoCount;
}
function cycleWeaponArsenal(){
 currentWeaponIndex=(currentWeaponIndex+1)%weaponsList.length;
 updateWeaponHud();triggerAchievement("Arsenal Pesado","Equipou: "+currentWeapon);
}
function shootWeapon(){
 if(inVehicle||weaponAmmo[currentWeaponIndex]<=0||shootCooldown>0)return;
 const w=weaponsList[currentWeaponIndex];
 weaponAmmo[currentWeaponIndex]--;ammoCount=weaponAmmo[currentWeaponIndex];
 shootCooldown=w.fireDelay;updateStatsDisplay();playSoundEffect("shoot");
 const yaw=player.rotation.y+cameraAngleY;
 for(let i=0;i<w.projectiles;i++){
  const geo=new THREE.SphereGeometry(i===0?.1:.075,5,5),mat=new THREE.MeshBasicMaterial({color:w.color});
  const bullet=new THREE.Mesh(geo,mat);
  bullet.position.copy(player.position);bullet.position.y+=1.3;
  const dir=new THREE.Vector3((Math.random()-.5)*w.spread,(Math.random()-.5)*w.spread*.35,-1).normalize();
  dir.applyAxisAngle(new THREE.Vector3(0,1,0),yaw);
  bullet.userData={velocity:dir.multiplyScalar(w.velocity),life:w.range/w.velocity,damage:w.damage};
  scene.add(bullet);bullets.push(bullet);
 }
}
function updateBullets(dt){
 for(let i=bullets.length-1;i>=0;i--){
  const bullet=bullets[i];bullet.position.addScaledVector(bullet.userData.velocity,dt*60);bullet.userData.life-=dt*60;
  let hit=false;
  for(const ped of pedestrians){
   if(!ped.userData.isRagdoll&&bullet.position.distanceTo(ped.position)<1){
    ped.userData.isRagdoll=true;ped.userData.velocity=new THREE.Vector3((Math.random()-.5)*.5,.5,(Math.random()-.5)*.5);
    addWanted(1);hit=true;break;
   }
  }
  if(!hit)for(const cop of policeCars){
   if(bullet.position.distanceTo(cop.position)<2.4){
    cop.userData.health-=bullet.userData.damage;addWanted(2);hit=true;
    if(cop.userData.health<=0){scene.remove(cop);policeCars.splice(policeCars.indexOf(cop),1)}
    break;
   }
  }
  if(!hit)for(const npc of npcVehicles){
   if(bullet.position.distanceTo(npc.position)<2.3){addWanted(1);npc.userData.hitCooldown=1;hit=true;break}
  }
  if(hit||bullet.userData.life<=0){scene.remove(bullet);bullet.geometry.dispose();bullet.material.dispose();bullets.splice(i,1)}
 }
 shootCooldown=Math.max(0,shootCooldown-dt);
}

/* ---------- AI / POLICE ---------- */
function updatePedestrianAI(dt){
 const target=playerPos();
 for(const ped of pedestrians){
  if(ped.userData.isRagdoll){
   if(ped.userData.velocity)ped.position.addScaledVector(ped.userData.velocity,dt*60);
   ped.userData.velocity.y-=.02*dt*60;
   continue;
  }
  const dx=ped.position.x-target.x,dz=ped.position.z-target.z;
  const dist=Math.hypot(dx,dz);
  if(dist<12){
   const len=dist||1;ped.position.x+=(dx/len)*.08*dt*60;ped.position.z+=(dz/len)*.08*dt*60;
  }else{
   ped.userData.patrolAngle+=.01*dt*60;
   ped.position.x+=Math.sin(ped.userData.patrolAngle)*.02*dt*60;
   ped.position.z+=Math.cos(ped.userData.patrolAngle)*.02*dt*60;
  }
  ped.position.x=clamp(ped.position.x,-CITY_LIMIT+8,CITY_LIMIT-8);
  ped.position.z=clamp(ped.position.z,-CITY_LIMIT+8,CITY_LIMIT-8);
 }
}
function setupWantedSystem(){updateWantedDisplay()}
function addWanted(amount){
 wantedLevel=clamp(wantedLevel+amount,0,5);wantedSearchTimer=55;updateWantedDisplay();spawnPoliceCars();
}
function updateWantedDisplay(){
 const el=$("wanted-stars");if(el)el.innerText=wantedLevel?"⭐".repeat(wantedLevel):"Nenhum";
}
function spawnPoliceCars(){
 const desired=wantedLevel?Math.min(7,wantedLevel+1):0;
 const bodyMat=new THREE.MeshStandardMaterial({color:0x172f50,metalness:.48,roughness:.38});
 const glassMat=new THREE.MeshStandardMaterial({color:0x101c27,metalness:.2,roughness:.2});
 const redMat=new THREE.MeshStandardMaterial({color:0xff263e,emissive:0x9b0014,emissiveIntensity:.8});
 const blueMat=new THREE.MeshStandardMaterial({color:0x278dff,emissive:0x063d9b,emissiveIntensity:.8});
 const target=playerPos();
 while(policeCars.length<desired){
  const cop=new THREE.Group();
  const body=new THREE.Mesh(new THREE.BoxGeometry(2.2,.82,4.5),bodyMat);body.position.y=.62;cop.add(body);
  const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.7,.65,2.1),glassMat);cabin.position.set(0,1.28,.05);cop.add(cabin);
  const bar=new THREE.Mesh(new THREE.BoxGeometry(1.15,.16,.34),bodyMat);bar.position.set(0,1.7,-.05);cop.add(bar);
  const red=new THREE.Mesh(new THREE.BoxGeometry(.42,.18,.3),redMat);red.position.set(-.3,1.82,-.05);cop.add(red);
  const blue=new THREE.Mesh(new THREE.BoxGeometry(.42,.18,.3),blueMat);blue.position.set(.3,1.82,-.05);cop.add(blue);
  const tires=new THREE.MeshStandardMaterial({color:0x141619,roughness:.9});
  const wheelGeo=new THREE.CylinderGeometry(.37,.37,.27,10);
  for(const wx of [-1,1])for(const wz of [-1.35,1.35]){const wheel=new THREE.Mesh(wheelGeo,tires);wheel.rotation.z=Math.PI/2;wheel.position.set(wx,.38,wz);cop.add(wheel)}
  const axis=Math.random()<.5?"x":"z",lane=(Math.random()<.5?-1:1)*4;
  const road=value=>clamp(Math.round((value+CITY_EDGE)/100)*100-CITY_EDGE,-CITY_EDGE,CITY_EDGE);
  if(axis==="x")cop.position.set(clamp(target.x+(Math.random()<.5?-1:1)*85,-CITY_LIMIT,CITY_LIMIT),0,road(target.z)+lane);
  else cop.position.set(road(target.x)+lane,0,clamp(target.z+(Math.random()<.5?-1:1)*85,-CITY_LIMIT,CITY_LIMIT));
  cop.lookAt(target);cop.userData={health:100,flash:Math.random()*Math.PI*2,state:"chase",officer:null};
  scene.add(cop);policeCars.push(cop);
 }
}
function updatePoliceAI(dt){
 if(!wantedLevel||gameOver)return;
 const target=playerPos();let closest=Infinity;
 for(const cop of policeCars){
  const ud=cop.userData;
  if(ud.state==='arrested')continue;
  if(ud.state==='chase'){
   const dir=new THREE.Vector3().subVectors(target,cop.position);dir.y=0;
   const distance=dir.length();closest=Math.min(closest,distance);
   // A viatura para antes de alcançar o jogador; nunca empurra nem bate no carro do jogador.
   if(distance>15){dir.normalize();cop.position.addScaledVector(dir,Math.min(7*dt,Math.max(0,distance-14)));cop.lookAt(target)}
   else{
    ud.state='exit';ud.exitTimer=.85;ud.officer=createCharacterGroup({shirt:0x182a42,pants:0x101923,skin:0xc9906d});
    ud.officer.position.copy(cop.position).add(new THREE.Vector3(2.7,0,0).applyAxisAngle(new THREE.Vector3(0,1,0),cop.rotation.y));
    ud.officer.rotation.y=cop.rotation.y;scene.add(ud.officer);
   }
  } else if(ud.state==='exit'){
   ud.exitTimer-=dt;
   if(ud.exitTimer<=0)ud.state='walk';
   animateCharacter(ud.officer,dt,false);
  } else if(ud.state==='walk'){
   const goal=playerPos();const dir=new THREE.Vector3().subVectors(goal,ud.officer.position);dir.y=0;
   const distance=dir.length();closest=Math.min(closest,distance);
   if(distance>1.7){dir.normalize();ud.officer.position.addScaledVector(dir,Math.min(2.15*dt,distance-1.4));ud.officer.rotation.y=Math.atan2(dir.x,dir.z);animateCharacter(ud.officer,dt,true)}
   else{
    ud.state='arrested';gameOver=true;isGamePaused=true;
    const overlay=$('game-over');if(overlay)overlay.style.display='flex';
    keys.forward=keys.backward=keys.left=keys.right=false;
    if(ud.officer)animateCharacter(ud.officer,dt,false);
   }
  }
  ud.flash+=dt*12;
  if(cop.children[3])cop.children[3].visible=Math.sin(ud.flash)>-.1;
  if(cop.children[4])cop.children[4].visible=!cop.children[3].visible;
 }
 if(closest<105)wantedSearchTimer=45;else wantedSearchTimer-=dt;
 if(wantedSearchTimer<=0){
  wantedLevel=Math.max(0,wantedLevel-1);wantedSearchTimer=wantedLevel?38:0;updateWantedDisplay();
  const desired=wantedLevel?Math.min(7,wantedLevel+1):0;
  while(policeCars.length>desired){const cop=policeCars.pop();if(cop.userData.officer)scene.remove(cop.userData.officer);scene.remove(cop)}
  if(wantedLevel===0){for(const cop of policeCars){if(cop.userData.officer)scene.remove(cop.userData.officer);scene.remove(cop)}policeCars.length=0}
  else spawnPoliceCars();
 }
}

/* ---------- MISSIONS ---------- */
function setupMissionSystem(){}
function startDeliveryMission(){
 if(currentMission)return;
 const destination=cityLocations[Math.floor(Math.random()*cityLocations.length)];
 currentMission={x:destination.x+38,z:destination.z,reward:300};
 gpsTarget=currentMission;
 const geo=new THREE.CylinderGeometry(2,2,25,12);
 missionMarker=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:0x00ffff,transparent:true,opacity:.55}));
 missionMarker.position.set(currentMission.x,12.5,currentMission.z);scene.add(missionMarker);
 showMission("Vá até o ponto ciano!"); 
}
function showMission(t){let e=$("mission-text");if(!e){e=document.createElement("div");e.id="mission-text";e.className="hud";e.style.position="absolute";e.style.top="185px";e.style.left="10px";$("ui").appendChild(e)}e.innerText="📋 "+t}
function updateMissionSystem(){
 if(!currentMission)return;
 if(playerPos().distanceTo(new THREE.Vector3(currentMission.x,0,currentMission.z))<6){
  money+=currentMission.reward;
  if(missionMarker)scene.remove(missionMarker);
  missionMarker=null;currentMission=null;gpsTarget=null;
  showMission("Missão concluída! +$300");triggerAchievement("Entregador","Concluiu uma missão de entrega.");
  setTimeout(()=>{if(!currentMission)showMission("Nenhuma missão")},3500);
 }
}

/* ---------- GARAGE / ECONOMY ---------- */
function setupGarageSystem(){}
function setupVehicleCustomization(){}
function changeCarColor(hex){
 if(!vehicle)return;
 vehicle.traverse(c=>{if(c.isMesh&&c.material&&c.material.color)c.material.color.setHex(hex)});
 triggerAchievement("Estilo de Luxo","Customizou a pintura do veículo.");
}
function repairCar(){
 if(money>=100&&carDamage>0){money-=100;carDamage=0;fuel=100;updateStatsDisplay()}
}
function storeCurrentVehicle(){
 if(!inVehicle)return;
 storedGarageVehicles.push({color:0xff0055});
 triggerAchievement("Veículo Guardado","Salvou um veículo na garagem.");
}
function spawnGarageVehicle(){
 if(!storedGarageVehicles.length)return;
 vehicle.position.copy(player.position).add(new THREE.Vector3(3,0,3));inVehicle=true;player.visible=false;
 triggerAchievement("Frota Liberada","Retirou um veículo guardado.");
}
function setupEconomyAndStores(){}
function buyStoreItem(type){
 if(type==="heal"&&money>=20&&playerHealth<100){money-=20;playerHealth=clamp(playerHealth+25,0,100)}
 if(type==="ammo"&&money>=50){money-=50;weaponAmmo[currentWeaponIndex]+=30;ammoCount=weaponAmmo[currentWeaponIndex]}
 updateStatsDisplay();
}
function updateStatsDisplay(){
 if($("money"))$("money").innerText=money;
 if($("health-value"))$("health-value").innerText=Math.round(playerHealth);
 if($("fuel"))$("fuel").innerText=Math.round(fuel);
 if($("car-damage"))$("car-damage").innerText=Math.round(carDamage);
 if($("ammo-count"))$("ammo-count").innerText=ammoCount;
}

/* ---------- AUDIO ---------- */
// Música de fundo: navegadores móveis só permitem iniciar após interação do jogador.
let backgroundMusicStarted=false;
function toggleBackgroundMusic(){
 const music=$("bg-music");
 if(!music)return;
 if(music.paused){
  music.volume=0.28;
  music.play().then(()=>{backgroundMusicStarted=true;$("btn-music").innerText="🔊";}).catch(()=>{$("btn-music").innerText="🎵";});
 }else{music.pause();$("btn-music").innerText="🔇";}
}
function startBackgroundMusicAfterInteraction(){
 const music=$("bg-music");
 if(!music||backgroundMusicStarted)return;
 music.volume=0.28;
 music.play().then(()=>{backgroundMusicStarted=true;$("btn-music").innerText="🔊";}).catch(()=>{});
}

function initAudioSystem(){
 addEventListener("pointerdown",()=>{
  startBackgroundMusicAfterInteraction();
  if(!audioCtx)audioCtx=new (window.AudioContext||window.webkitAudioContext)();
  if(audioCtx.state==="suspended")audioCtx.resume();
 },{once:false});
}
function playSoundEffect(type){
 if(!audioCtx)return;
 const o=audioCtx.createOscillator(),g=audioCtx.createGain(),now=audioCtx.currentTime;
 o.connect(g);g.connect(audioCtx.destination);
 if(type==="shoot"){o.type="square";o.frequency.setValueAtTime(400,now);o.frequency.exponentialRampToValueAtTime(40,now+.1);g.gain.setValueAtTime(.15,now);g.gain.exponentialRampToValueAtTime(.01,now+.1);o.start();o.stop(now+.1)}
 else if(type==="crash"){o.type="sawtooth";o.frequency.setValueAtTime(120,now);o.frequency.linearRampToValueAtTime(30,now+.2);g.gain.setValueAtTime(.2,now);g.gain.exponentialRampToValueAtTime(.01,now+.2);o.start();o.stop(now+.2)}
 else {o.type="triangle";o.frequency.setValueAtTime(320,now);g.gain.setValueAtTime(.08,now);g.gain.exponentialRampToValueAtTime(.01,now+.2);o.start();o.stop(now+.2)}
}
function startEngineSound(){
 if(!audioCtx||engineOscillator)return;
 engineOscillator=audioCtx.createOscillator();engineGain=audioCtx.createGain();
 engineOscillator.type="triangle";engineOscillator.frequency.value=48;engineGain.gain.value=.006;
 engineOscillator.connect(engineGain);engineGain.connect(audioCtx.destination);engineOscillator.start();
}
function updateEngineSound(v){
 if(engineOscillator&&audioCtx)engineOscillator.frequency.setTargetAtTime(48+Math.abs(v)*24,audioCtx.currentTime,.16);
}
function stopEngineSound(){if(engineOscillator){try{engineOscillator.stop()}catch(e){}engineOscillator.disconnect();engineOscillator=null;engineGain=null}}

/* ---------- SMOKE ---------- */
const smokeGeo=new THREE.SphereGeometry(.25,5,5);
const smokeMatBase=new THREE.MeshBasicMaterial({color:0xdddddd,transparent:true,opacity:.5});
function createSmokeParticle(pos){
 const p=new THREE.Mesh(smokeGeo,smokeMatBase.clone());p.position.copy(pos);p.position.y+=.2;scene.add(p);
 smokeParticles.push({mesh:p,life:1,scale:.25});
}
function updateSmokeParticles(dt){
 for(let i=smokeParticles.length-1;i>=0;i--){
  const s=smokeParticles[i];s.life-=dt;s.scale+=dt*.9;s.mesh.scale.setScalar(s.scale);s.mesh.material.opacity=Math.max(0,s.life*.5);s.mesh.position.y+=dt*.6;
  if(s.life<=0){scene.remove(s.mesh);s.mesh.material.dispose();smokeParticles.splice(i,1)}
 }
}

/* ---------- COLLECTIBLES ---------- */
function setupHiddenPackages(){
 const geo=new THREE.BoxGeometry(.8,.8,.8),mat=new THREE.MeshStandardMaterial({color:0xff00ff,metalness:.6});
 for(let i=0;i<10;i++){
  const p=new THREE.Mesh(geo,mat),street=(Math.floor(Math.random()*16)-7.5)*100,along=(Math.random()-.5)*1460,lane=(Math.random()<.5?-1:1)*5;
  if(Math.random()<.5)p.position.set(along,.5,street+lane);else p.position.set(street+lane,.5,along);
  scene.add(p);hiddenPackages.push(p);
 }
}
function updateHiddenPackages(dt){
 const pos=playerPos();
 for(let i=hiddenPackages.length-1;i>=0;i--){
  const p=hiddenPackages[i];p.rotation.y+=dt*2;
  if(p.position.distanceTo(pos)<2){scene.remove(p);hiddenPackages.splice(i,1);collectedPackagesCount++;money+=500;updateStatsDisplay();triggerAchievement("Caçador de Pacotes",`Coletou ${collectedPackagesCount}/10 pacotes.`)}
 }
}

/* ---------- CAMERA / MINIMAP ---------- */
function setupCameraSwitchSystem(){}
function toggleCameraMode(){if(inVehicle)cameraMode=(cameraMode+1)%3}
function updateVehicleCamera(){
 if(!inVehicle||!vehicle)return;
 const off=cameraMode===1?new THREE.Vector3(0,2.1,3.8):cameraMode===2?new THREE.Vector3(0,7.5,13):new THREE.Vector3(0,3.4,7.5);
 off.applyAxisAngle(new THREE.Vector3(0,1,0),vehicle.rotation.y+cameraAngleY);
 camera.position.lerp(vehicle.position.clone().add(off),.12);
 const forward=new THREE.Vector3(0,0,-1).applyQuaternion(vehicle.quaternion);
 const lookTarget=vehicle.position.clone().add(new THREE.Vector3(0,1,0)).addScaledVector(forward,cameraMode===2?5:8);
 camera.lookAt(lookTarget);
}
function setupMinimapSystem(){minimapCtx=$("minimap-canvas").getContext("2d")}
function updateMinimap(){
 if(!minimapCtx)return;
 const ctx=minimapCtx,pos=playerPos(),S=140,scale=.08;
 ctx.clearRect(0,0,S,S);ctx.fillStyle="#09110f";ctx.fillRect(0,0,S,S);
 ctx.strokeStyle="#343b3a";ctx.lineWidth=2;
 for(let street=-CITY_EDGE;street<=CITY_EDGE;street+=100){
  let x=70+(street-pos.x)*scale,z=70+(street-pos.z)*scale;
  ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,S);ctx.stroke();
  ctx.beginPath();ctx.moveTo(0,z);ctx.lineTo(S,z);ctx.stroke();
 }
 for(const place of cityLocations){
  const x=(place.x-pos.x)*scale+70,z=(place.z-pos.z)*scale+70;
  if(x>0&&x<S&&z>0&&z<S){ctx.fillStyle=place.type===0?"#8dd68c":place.type===2?"#ff8175":"#d3c79a";ctx.fillRect(x-1.3,z-1.3,2.6,2.6)}
 }
 for(const p of hiddenPackages){let x=(p.position.x-pos.x)*scale+70,z=(p.position.z-pos.z)*scale+70;if(x>0&&x<S&&z>0&&z<S){ctx.fillStyle="#f0f";ctx.fillRect(x-2,z-2,4,4)}}
 if(currentMission){let x=(currentMission.x-pos.x)*scale+70,z=(currentMission.z-pos.z)*scale+70;ctx.fillStyle="#0ff";ctx.beginPath();ctx.arc(x,z,4,0,Math.PI*2);ctx.fill()}
 for(const cop of policeCars){let x=(cop.position.x-pos.x)*scale+70,z=(cop.position.z-pos.z)*scale+70;if(x>0&&x<S&&z>0&&z<S){ctx.fillStyle="#f33";ctx.fillRect(x-2,z-2,4,4)}}
 ctx.fillStyle="#ff3980";ctx.beginPath();ctx.arc(70,70,4,0,Math.PI*2);ctx.fill();
}

/* ---------- RADIO ---------- */
function setupRadioSystem(){}
function toggleRadio(){
 if(!audioCtx)return;
 if(!radioPlaying){radioPlaying=true;currentStation=1;startRadioLoop()}
 else{currentStation++;if(currentStation>2){radioPlaying=false;stopRadioLoop()}}
}
function startRadioLoop(){
 stopRadioLoop();radioInterval=setInterval(()=>{
  if(!radioPlaying||!audioCtx)return;
  const notes=currentStation===1?[220,247,293,329,370]:[110,130,164,196],n=notes[Math.floor(Math.random()*notes.length)];
  const o=audioCtx.createOscillator(),g=audioCtx.createGain(),now=audioCtx.currentTime;o.type=currentStation===1?"sine":"sawtooth";o.frequency.value=n;g.gain.setValueAtTime(.025,now);g.gain.exponentialRampToValueAtTime(.001,now+.3);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(now+.3)
 },400)
}
function stopRadioLoop(){if(radioInterval){clearInterval(radioInterval);radioInterval=null}}

/* ---------- WEATHER / TIME ---------- */
function setupWeatherSystem(){
 const geo=new THREE.BufferGeometry(),count=1100,pos=new Float32Array(count*3);
 for(let i=0;i<pos.length;i+=3){pos[i]=(Math.random()-.5)*1550;pos[i+1]=Math.random()*70;pos[i+2]=(Math.random()-.5)*1550}
 geo.setAttribute("position",new THREE.BufferAttribute(pos,3));
 rainParticles=new THREE.Points(geo,new THREE.PointsMaterial({color:0xaaaaaa,size:.35,transparent:true,opacity:.5}));
 rainParticles.visible=false;scene.add(rainParticles)
}
function toggleWeather(){isRaining=!isRaining;rainParticles.visible=isRaining;$("weather-status").innerText=isRaining?"Chovendo":"Ensolarado"}
function updateWeather(dt){
 if(!isRaining)return;
 const p=rainParticles.geometry.attributes.position.array;
 for(let i=1;i<p.length;i+=3){p[i]-=35*dt;if(p[i]<0)p[i]=70}
 rainParticles.geometry.attributes.position.needsUpdate=true;
}
function setupTimeOfDaySystem(){}
function updateTimeOfDay(dt){
 gameTime+=timeSpeed*dt*60;if(gameTime>=24)gameTime=0;
 const angle=(gameTime/24)*Math.PI*2;
 directionalLight.position.set(Math.cos(angle)*150,Math.max(20,Math.sin(angle)*150),50);
 directionalLight.intensity=gameTime>6&&gameTime<18?(.45+Math.sin((gameTime-6)/12*Math.PI)*.8):.12;
 const night=gameTime>=18||gameTime<=6;
 scene.background.setHex(night?0x080817:0x87ceeb);
 scene.fog.color.setHex(night?0x09091a:0x8899aa);
 $("time-display").innerText=`${String(Math.floor(gameTime)).padStart(2,"0")}:${String(Math.floor((gameTime%1)*60)).padStart(2,"0")}`;
}

/* ---------- RACE ---------- */
function setupTimeTrialSystem(){}
function startStreetRace(){
 if(isRacing)return;
 isRacing=true;raceTimer=35;currentCheckpoint=0;
 triggerAchievement("Piloto de Fuga","Iniciou uma corrida contra o relógio.");
}
function updateTimeTrial(dt){
 if(!isRacing)return;
 raceTimer-=dt;
 if(raceTimer<=0){isRacing=false;return}
 const cp=raceCheckpoints[currentCheckpoint],p=playerPos();
 if(Math.hypot(p.x-cp.x,p.z-cp.z)<7){
  currentCheckpoint++;
  if(currentCheckpoint>=raceCheckpoints.length){isRacing=false;money+=1000;triggerAchievement("Rei das Ruas","Completou a corrida e ganhou $1000.")}
 }
}

/* ---------- ACHIEVEMENTS / STATS ---------- */
function setupAchievementSystem(){}
function triggerAchievement(title,description){
 if(unlockedAchievements.includes(title))return;
 unlockedAchievements.push(title);
 const c=$("toast-container"),t=document.createElement("div");t.className="toast";
 t.innerHTML=`<b style="color:#0ff">🏆 CONQUISTA</b><br><strong style="color:#f07">${title}</strong><br><small>${description}</small>`;
 c.appendChild(t);setTimeout(()=>t.remove(),4000);playSoundEffect("horn");
}
function setupStatsDashboard(){}
function toggleStatsModal(){const m=$("stats-modal");m.style.display=m.style.display==="flex"?"none":"flex";if(m.style.display==="flex"){ $("stat-money").innerText="$"+money;$("stat-packages").innerText=collectedPackagesCount;$("stat-achievements").innerText=unlockedAchievements.length;$("stat-race").innerText=isRacing?"Em andamento":"Pronta"}} 
function setupPauseMenu(){}
function togglePauseGame(){isGamePaused=!isGamePaused;$("pause-menu").style.display=isGamePaused?"flex":"none"}
function toggleFullScreen(){if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.()}
function resetGameSession(){location.reload()}

/* ---------- CHEATS ---------- */
function setupCheatCodeSystem(){}
function submitCheatCode(code){
 code=(code||prompt("Digite o cheat:")||"").trim().toUpperCase();
 if(code==="HESOYAM"||code==="DINHEIRO"){money+=5000;playerHealth=100}
 else if(code==="WEAPON"||code==="ARMAS"){weaponAmmo=weaponAmmo.map(amount=>amount+100);ammoCount=weaponAmmo[currentWeaponIndex]}
 else return;
 updateStatsDisplay();triggerAchievement("Trapaceiro Profissional","Código especial ativado.");
}

/* ---------- AMBIENCE ---------- */
function setupStreetLights(){
 const postGeo=new THREE.CylinderGeometry(.08,.12,5.2,5),postMat=new THREE.MeshStandardMaterial({color:0x34383a,metalness:.55,roughness:.7});
 const headGeo=new THREE.BoxGeometry(.72,.2,1.25),headMat=new THREE.MeshStandardMaterial({color:0xffd899,emissive:0xffb94d,emissiveIntensity:.06});
 const positions=[{x:30,z:30},{x:-30,z:30},{x:30,z:-30},{x:-30,z:-30},{x:90,z:90},{x:-90,z:-90}];
 for(const p of positions){
  const post=new THREE.Mesh(postGeo,postMat);post.position.set(p.x,2.6,p.z);scene.add(post);
  const l=new THREE.PointLight(0xffaa44,0,18);l.position.set(p.x,5.2,p.z);scene.add(l);streetLights.push(l)
 }
 const lampPositions=[];
 for(let street=-CITY_EDGE;street<=CITY_EDGE;street+=200){
  for(const side of [-1,1])for(let along=-700;along<=700;along+=200){
   lampPositions.push([along,street+side*16]);lampPositions.push([street+side*16,along]);
  }
 }
 const poles=new THREE.InstancedMesh(postGeo,postMat,lampPositions.length),heads=new THREE.InstancedMesh(headGeo,headMat,lampPositions.length),dummy=new THREE.Object3D();
 lampPositions.forEach(([x,z],i)=>{
  dummy.position.set(x,2.6,z);dummy.updateMatrix();poles.setMatrixAt(i,dummy.matrix);
  dummy.position.set(x,5.15,z);dummy.updateMatrix();heads.setMatrixAt(i,dummy.matrix);
 });
 poles.instanceMatrix.needsUpdate=true;heads.instanceMatrix.needsUpdate=true;scene.add(poles,heads);
 streetLampMaterial=headMat;
}
function updateStreetLights(){const n=gameTime>=18||gameTime<=6;for(const l of streetLights)l.intensity=n?1.8:0;if(streetLampMaterial)streetLampMaterial.emissiveIntensity=n ? .9 : .06}
function setupNeonSigns(){
 const geo=new THREE.BoxGeometry(4,1.2,.2);
 [{x:0,z:-40,c:0xff007f},{x:50,z:0,c:0x00ffff},{x:-50,z:20,c:0xffaa00},{x:0,z:80,c:0x00ff00}].forEach(d=>{
  const s=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:d.c}));s.position.set(d.x,6,d.z);scene.add(s);neonSigns.push({mesh:s,color:d.c})
 })
}
function updateNeonSigns(){const n=gameTime>=18||gameTime<=6;for(const s of neonSigns)s.mesh.visible=n}
function setupDistantHorizon(){
 const group=new THREE.Group(),geo=new THREE.BoxGeometry(16,60,16),mat=new THREE.MeshStandardMaterial({color:0x111122});
 for(let i=0;i<60;i++){const a=i/60*Math.PI*2,r=900,h=35+(i%7)*12,b=new THREE.Mesh(geo,mat);b.scale.set(1+(i%3)*.2,h/60,1+((i+2)%3)*.2);b.position.set(Math.cos(a)*r,h/2,Math.sin(a)*r);group.add(b)}
 scene.add(group)
}
function setupAmbientDustSystem(){
 const count=420,g=new THREE.BufferGeometry(),p=new Float32Array(count*3);
 for(let i=0;i<p.length;i+=3){p[i]=(Math.random()-.5)*1500;p[i+1]=Math.random()*28;p[i+2]=(Math.random()-.5)*1500}
 g.setAttribute("position",new THREE.BufferAttribute(p,3));ambientDustParticles=new THREE.Points(g,new THREE.PointsMaterial({color:0xffeeaa,size:.3,transparent:true,opacity:.3}));scene.add(ambientDustParticles)
}
function updateAmbientDust(dt){
 if(!ambientDustParticles)return;const p=ambientDustParticles.geometry.attributes.position.array;
 for(let i=0;i<p.length;i+=3){p[i]+=.8*dt;p[i+2]+=.4*dt;if(p[i]>750)p[i]=-750;if(p[i+2]>750)p[i+2]=-750}
 ambientDustParticles.geometry.attributes.position.needsUpdate=true
}
function setupUrbanWaterFountains(){
 const water=new THREE.Mesh(new THREE.CylinderGeometry(8,8,.4,24),new THREE.MeshStandardMaterial({color:0x167f9d,metalness:.5,roughness:.15,transparent:true,opacity:.82}));water.position.set(25,.2,25);scene.add(water);
 const rim=new THREE.Mesh(new THREE.TorusGeometry(8,.55,10,24),new THREE.MeshStandardMaterial({color:0x77736b,roughness:.72}));rim.rotation.x=Math.PI/2;rim.position.set(25,.5,25);scene.add(rim);
 const inner=new THREE.Mesh(new THREE.CylinderGeometry(2.6,3.2,.65,16),new THREE.MeshStandardMaterial({color:0x8c8a82,roughness:.8}));inner.position.set(25,.55,25);scene.add(inner);
 const jet=new THREE.Mesh(new THREE.CylinderGeometry(.14,.22,2.2,10),new THREE.MeshStandardMaterial({color:0xc9d5d0,metalness:.6,roughness:.2}));jet.position.set(25,1.9,25);scene.add(jet);
 const spray=new THREE.Mesh(new THREE.SphereGeometry(.9,10,8),new THREE.MeshStandardMaterial({color:0x78cce2,transparent:true,opacity:.6,roughness:.15}));spray.position.set(25,3.1,25);scene.add(spray);
}
function setupUrbanParksAndTrees(){
 const trees=[];const bushes=[];
 for(let street=-CITY_EDGE;street<=CITY_EDGE;street+=100){
  for(const side of [-1,1])for(let along=-725;along<=725;along+=70){
   const crossGap=Math.min(Math.abs(along%100),100-Math.abs(along%100));
   if(crossGap<18)continue;
   const scale=.82+((Math.abs(street+along)%5)*.08);
   trees.push({x:along,z:street+side*17,scale,kind:Math.abs(along+street)%3===0?1:0});
   trees.push({x:street+side*17,z:along,scale,kind:Math.abs(along-street)%4===0?1:0});
  }
 }
 for(const place of cityLocations){
  if(place.type!==0&&place.type!==11)continue;
  for(let ix=-2;ix<=2;ix++)for(let iz=-2;iz<=2;iz++){
   if(Math.abs(ix)<1||Math.abs(iz)<1)continue;
   if(place.type===11&&Math.abs(iz*12-13)<12&&Math.abs(ix*12)<20)continue;
   const x=place.x+ix*12,z=place.z+iz*12,scale=1+(Math.abs(ix+iz)%3)*.12;
   trees.push({x,z,scale,kind:(ix+iz+5)%3===0?1:0});
   if((ix+iz)%2===0)bushes.push({x:x+4,z:z+3,scale:.8+((ix-iz+4)%3)*.16});
  }
 }
 const trunkGeometry=new THREE.CylinderGeometry(.28,.48,4.5,7);
 const trunkMaterial=new THREE.MeshStandardMaterial({color:0x654833,roughness:1});
 const trunkMesh=new THREE.InstancedMesh(trunkGeometry,trunkMaterial,trees.length);
 const broad=trees.filter(tree=>tree.kind===0),conifers=trees.filter(tree=>tree.kind===1);
 const broadMesh=new THREE.InstancedMesh(new THREE.SphereGeometry(2.7,8,7),new THREE.MeshStandardMaterial({color:0x4f8950,roughness:1}),broad.length);
 const coneMesh=new THREE.InstancedMesh(new THREE.ConeGeometry(3.1,7,7),new THREE.MeshStandardMaterial({color:0x367551,roughness:1}),conifers.length);
 const dummy=new THREE.Object3D();
 trees.forEach((tree,i)=>{
  dummy.position.set(tree.x,2.2*tree.scale,tree.z);dummy.scale.setScalar(tree.scale);dummy.updateMatrix();trunkMesh.setMatrixAt(i,dummy.matrix);
 });
 broad.forEach((tree,i)=>{
  dummy.position.set(tree.x,5.1*tree.scale,tree.z);dummy.scale.setScalar(tree.scale);dummy.updateMatrix();broadMesh.setMatrixAt(i,dummy.matrix);
  broadMesh.setColorAt(i,new THREE.Color().setHSL(.29+((Math.abs(tree.x+tree.z)%7)*.006),.38,.31+((Math.abs(tree.x-tree.z)%5)*.012)));
 });
 conifers.forEach((tree,i)=>{
  dummy.position.set(tree.x,5.7*tree.scale,tree.z);dummy.scale.setScalar(tree.scale);dummy.updateMatrix();coneMesh.setMatrixAt(i,dummy.matrix);
  coneMesh.setColorAt(i,new THREE.Color().setHSL(.36,.34,.28+((Math.abs(tree.x+tree.z)%4)*.015)));
 });
 trunkMesh.instanceMatrix.needsUpdate=true;broadMesh.instanceMatrix.needsUpdate=true;coneMesh.instanceMatrix.needsUpdate=true;
 if(broadMesh.instanceColor)broadMesh.instanceColor.needsUpdate=true;
 if(coneMesh.instanceColor)coneMesh.instanceColor.needsUpdate=true;
 scene.add(trunkMesh,broadMesh,coneMesh);
 const bushMesh=new THREE.InstancedMesh(new THREE.SphereGeometry(1.25,6,5),new THREE.MeshStandardMaterial({color:0x4f8748,roughness:1}),bushes.length);
 bushes.forEach((bush,i)=>{dummy.position.set(bush.x,.9,bush.z);dummy.scale.set(bush.scale,.72*bush.scale,bush.scale);dummy.updateMatrix();bushMesh.setMatrixAt(i,dummy.matrix)});
 bushMesh.instanceMatrix.needsUpdate=true;scene.add(bushMesh);
}
function setupAtmosphericFog(){scene.fog=new THREE.FogExp2(0x8899aa,.0011)}
function updateAtmosphericFog(){scene.fog.density=(gameTime>=18||gameTime<=6)?.0022:.0011}
function setupAmbientAirTraffic(){
 const geo=new THREE.ConeGeometry(.5,2,4);geo.rotateX(Math.PI/2);const mat=new THREE.MeshBasicMaterial({color:0xffffff});
 for(let i=0;i<3;i++){const m=new THREE.Mesh(geo,mat);scene.add(m);ambientAircrafts.push({mesh:m,angle:Math.random()*6.28,radius:340+i*150,speed:.04+i*.01})}
}
function updateAmbientAirTraffic(dt){
 for(const a of ambientAircrafts){a.angle+=a.speed*dt*2;a.mesh.position.set(Math.cos(a.angle)*a.radius,90+Math.sin(a.angle*2)*8,Math.sin(a.angle)*a.radius);a.mesh.rotation.y=-a.angle}
}
function setupStreetFurniture(){
 const pole=new THREE.CylinderGeometry(.08,.08,3,5),pm=new THREE.MeshStandardMaterial({color:0x444444,metalness:.7}),sg=new THREE.BoxGeometry(1,1,.1),sm=new THREE.MeshStandardMaterial({color:0xcc0000});
 [{x:22,z:22},{x:-22,z:22},{x:22,z:-22},{x:-22,z:-22}].forEach(p=>{const g=new THREE.Group(),a=new THREE.Mesh(pole,pm),b=new THREE.Mesh(sg,sm);a.position.y=1.5;b.position.y=2.8;g.add(a,b);g.position.set(p.x,0,p.z);scene.add(g)})
}

/* ---------- MASTER ---------- */
function masterInit(){
 createTrafficSystem();
 setupWantedSystem();
 setupMissionSystem();
 setupWeaponSystem();
 setupWeaponArsenalSystem();
 setupGarageSystem();
 setupEconomyAndStores();
 setupVehicleCustomization();
 setupCameraSwitchSystem();
 setupMinimapSystem();
 setupWeatherSystem();
 setupTimeOfDaySystem();
 setupAchievementSystem();
 setupStatsDashboard();
 setupPauseMenu();
 setupCheatCodeSystem();
 setupHiddenPackages();
 setupTimeTrialSystem();
 setupStreetLights();
 setupNeonSigns();
 setupDistantHorizon();
 setupAmbientDustSystem();
 setupUrbanWaterFountains();
 setupUrbanParksAndTrees();
 setupAtmosphericFog();
 setupAmbientAirTraffic();
 setupStreetFurniture();
 initAudioSystem();
 updateStatsDisplay();
}

function gameLoop(now){
 requestAnimationFrame(gameLoop);
 const dt=Math.min((now-lastFrame)/1000,.05);lastFrame=now;
 if(!gameStarted||isGamePaused){renderer.render(scene,camera);return}

 updateGame(dt);
 updateTraffic(dt);
 updateBullets(dt);
 if(now-lastAIUpdate>50){const aiDt=Math.min(.1,(now-lastAIUpdate)/1000);updatePedestrianAI(aiDt);updatePoliceAI(aiDt);lastAIUpdate=now}
 updateMissionSystem();
 updateHiddenPackages(dt);
 updateTimeTrial(dt);
 updateWeather(dt);
 updateSmokeParticles(dt);
 updateTimeOfDay(dt);
 updateStreetLights();
 updateNeonSigns();
 updateAmbientDust(dt);
 updateAtmosphericFog();
 updateAmbientAirTraffic(dt);

 if(now-lastHudUpdate>160){updateStatsDisplay();updateMinimap();updateNearbyLocation();lastHudUpdate=now}
 renderer.render(scene,camera);
}

function onWindowResize(){
 camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.75))
}
addEventListener("resize",onWindowResize);

try {
 initEngine();
 setupControls();
 setupCameraDrag();
 masterInit();
 gameStarted=true;
 requestAnimationFrame(gameLoop);
} catch (err) {
 console.error('Falha ao iniciar Open World:', err);
 const box=document.createElement('div');
 box.style.cssText='position:fixed;z-index:999999;inset:12px;padding:16px;background:#300;color:#fff;font:14px Arial;white-space:pre-wrap;border-radius:10px;height:max-content';
 box.textContent='Erro ao iniciar o jogo: '+(err && err.message ? err.message : String(err))+'\nRecarregue a página. Se continuar, envie esta mensagem.';
 document.body.appendChild(box);
}

/* Touch/desktop extras */
$("btn-pause").addEventListener("contextmenu",e=>e.preventDefault());
$("btn-shoot").addEventListener("pointerdown",e=>{e.preventDefault();shootWeapon()});

/* Pequeno menu de loja acessível pelo console/JS:
   buyStoreItem("heal"), buyStoreItem("ammo")
   submitCheatCode("HESOYAM")
*/
window.togglePauseGame = togglePauseGame;
window.toggleFullScreen = toggleFullScreen;
window.resetGameSession = resetGameSession;
window.toggleStatsModal = toggleStatsModal;
